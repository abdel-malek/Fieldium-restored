package com.tradinos.network;

/**
 * Created by malek on 4/15/16.
 */
public interface FaildCallback  {
    public void OnFaild (Code errorCode , String Message);
}
