package com.tradinos.network;

/**
 * Created by malek on 4/22/16.
 */
public enum RequestMethod {
    Get,Post
}
