package com.tradinos.network;

/**
 * Created by malek on 4/15/16.
 */
public enum Code {

    ConnectionError , ParsingError , ServerError;
}
