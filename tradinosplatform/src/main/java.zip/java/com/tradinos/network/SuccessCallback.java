package com.tradinos.network;

/**
 * Created by malek on 4/15/16.
 */
public interface SuccessCallback<T> {
    public void OnSuccess (T result);
}
