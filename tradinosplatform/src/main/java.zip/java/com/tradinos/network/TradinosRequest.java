package com.tradinos.network;

import android.content.Context;
import android.util.Base64;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Farah on 4/22/16.
 */
public class TradinosRequest<T>  extends Request<JSONArray>  {

    private SuccessCallback<T> successCallback ;
    FaildCallback faildCallback ;
    private Map<String,String> parameters ;
    private Map<String,String> headers ;
    private Context context ;
    private TradinosParser<T> parser ;
    private boolean authenticationRequired = false;


    public TradinosRequest(Context context ,String url , RequestMethod method ,final TradinosParser<T> parser ,  SuccessCallback<T> successCallback , final FaildCallback faildCallback){

        super(method == RequestMethod.Get ? com.android.volley.Request.Method.GET : com.android.volley.Request.Method.POST, url, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                faildCallback.OnFaild(Code.ServerError, "Server Error !");
            }
        });

        this.context = context ;
        parameters = new HashMap<>();
        headers = new HashMap<>() ;
        this.successCallback = successCallback ;
        this.faildCallback = faildCallback ;
        this.parser = parser ;

    }

    public void turnOnAuthentication (String username , String password ) {
        try {
            String authenticationValue = "Basic " +
                    String.valueOf(Base64.encodeToString((username + ":" + password).getBytes(), Base64.NO_WRAP));
            getHeaders().put("Authorization",authenticationValue);
            authenticationRequired = true ;
        }catch (Exception e) {
        }
    }
    public void turnOffAuthentication () {
        authenticationRequired = false ;
    }

    public void Call (){
        InternetManager.getInstance(getContext()).addToRequestQueue(this) ;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }


    @Override
    protected Response<JSONArray> parseNetworkResponse(NetworkResponse response) {
        try {
            String data = new String(
                    response.data,
                    HttpHeaderParser.parseCharset(response.headers));

            JSONArray json = new JSONArray(data);
            return Response.success(
                    json,
                    HttpHeaderParser.parseCacheHeaders(response));
        } catch (JSONException e) {
            return Response.error(new ParseError( e));
        } catch (UnsupportedEncodingException e) {
            return Response.error(new ParseError(e));
        }
    }

    public void addParameter (String key,String value) {
        parameters.put(key,value) ;
    }


    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        return headers != null ? headers : super.getHeaders();
    }

    @Override
    public Map<String, String> getParams() {
        return parameters;
    }


    @Override
    protected void deliverResponse(JSONArray response) {
        try {
            JSONObject jsonObject = response.getJSONObject(0);
            boolean status = jsonObject.getBoolean("status") ;
            if (status){
                String data = jsonObject.getString("data");
                T result = (T) parser.Parse(data);
                successCallback.OnSuccess(result);
            }else{
                String message = jsonObject.getString("message") ;
                faildCallback.OnFaild(Code.ServerError, message);
            }
        }catch (JSONException e){
            faildCallback.OnFaild(Code.ParsingError, "Parsing Error");
        }
    }

    public boolean isAuthenticationRequired() {
        return authenticationRequired;
    }

    public void setAuthenticationRequired(boolean authenticationRequired) {
        this.authenticationRequired = authenticationRequired;
    }
}
